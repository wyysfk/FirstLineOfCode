package com.example.helloworld.patac;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;

import com.example.helloworld.R;

public class PatacInputBoxActivity extends AppCompatActivity {

    private PatacInputBox mPatacInputBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patac_input_box);
        mPatacInputBox = findViewById(R.id.patacinputbox);
        mPatacInputBox.setDefaultHint("请输入用户名");
        mPatacInputBox.setNotice("");

        mPatacInputBox.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String content = mPatacInputBox.getContent();
                if(content.length() < 6){
                    mPatacInputBox.setErrorNotice("输入文言长度要大于7个字符");
                }
                else{
                    mPatacInputBox.setNotice("");
                }
            }
        });

        mPatacInputBox.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                mPatacInputBox.setHint(v, hasFocus);
                if(hasFocus){
                    mPatacInputBox.setNotice("请输入用户名,长度大于7个字符");
                }else{
                    mPatacInputBox.setNotice("");
                }
            }
        });

    }
}
