package com.example.helloworld.patac;

import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import android.widget.NumberPicker;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.example.helloworld.R;

import java.lang.reflect.Field;
import java.util.Calendar;
import java.util.Locale;

public class PatacDatePicker extends LinearLayout {

    private NumberPicker mNpDate1, mNpDate2, mNpDate3;

    public PatacDatePicker(Context context) {
        super(context);
        init(context);
    }

    public PatacDatePicker(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public PatacDatePicker(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    public PatacDatePicker(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init(context);
    }

    private void init(Context context){
        LayoutInflater.from(context).inflate(R.layout.layout_patac_date_picker, this, true);
        mNpDate1 = findViewById(R.id.np_date1);
        mNpDate2 = findViewById(R.id.np_date2);
        mNpDate3 = findViewById(R.id.np_date3);

        Locale locale = context.getResources().getConfiguration().locale;
        String language = locale.getLanguage();
        boolean isChina = false;
        Log.d("PatacDatePicker","language=" + language);
        if(language.contains("zh")){
            isChina = true;
        }

        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH) + 1;
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        Log.d("PatacDatePicker", "年："+year+" 月："+month+" 日："+day);

        MyFormatter myFormatter = new MyFormatter();
        OnValueChangeListener valueChangeListener = new OnValueChangeListener();
        OnScrollStateChange scrollStateChange = new OnScrollStateChange();

        if(isChina){
            //年
            mNpDate1.setMinValue(1970);
            mNpDate1.setMaxValue(2100);
            mNpDate1.setValue(year);

            //月
            mNpDate2.setMinValue(1);
            mNpDate2.setMaxValue(12);
            mNpDate2.setValue(month);

            //日
            mNpDate3.setMinValue(1);
            mNpDate3.setMaxValue(30);
            mNpDate3.setValue(day);
        }else{
            //月
            String mounths[] = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
            mNpDate1.setMinValue(0);
            mNpDate1.setMaxValue(11);
            mNpDate1.setDisplayedValues(mounths);
            mNpDate1.setValue(month);

            //日
            mNpDate2.setMinValue(1);
            mNpDate2.setMaxValue(30);
            mNpDate2.setValue(day);

            //年
            mNpDate3.setMinValue(1970);
            mNpDate3.setMaxValue(2100);
            mNpDate3.setValue(year);
        }

        //mNpDate1.setFormatter(myFormatter);
        mNpDate1.setOnValueChangedListener(valueChangeListener);
        mNpDate1.setOnScrollListener(scrollStateChange);


        //mNpDate2.setFormatter(myFormatter);
        mNpDate2.setOnValueChangedListener(valueChangeListener);
        mNpDate2.setOnScrollListener(scrollStateChange);

        //mNpDate3.setFormatter(myFormatter);
        mNpDate3.setOnValueChangedListener(valueChangeListener);
        mNpDate3.setOnScrollListener(scrollStateChange);

        //设置分割线的颜色和高度
        setNumberPickerDivider(context, mNpDate1);
        setNumberPickerDivider(context, mNpDate2);
        setNumberPickerDivider(context, mNpDate3);

        //设置点击事件不弹键盘
        setDescendantFocusability(FOCUS_BLOCK_DESCENDANTS);
    }

    class MyFormatter implements NumberPicker.Formatter{

        @Override
        public String format(int value) {
            String tmpStr = String.valueOf(value);
            if(value < 10){
                tmpStr = "0" + tmpStr;
            }
            return tmpStr;
        }
    }

    class OnValueChangeListener implements NumberPicker.OnValueChangeListener{

        @Override
        public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
            switch (picker.getId()){
                case R.id.np_date1:
                    Log.d("onValueChange", "oldVal="+oldVal+",newVal="+newVal);
                    break;
                case R.id.np_date2:
                    Log.d("onValueChange", "oldVal="+oldVal+",newVal="+newVal);
                    break;
                case R.id.np_date3:
                    Log.d("onValueChange", "oldVal="+oldVal+",newVal="+newVal);
                    break;
            }
        }
    }

    class OnScrollStateChange implements NumberPicker.OnScrollListener{

        @Override
        public void onScrollStateChange(NumberPicker view, int scrollState) {
            switch (scrollState){
                case NumberPicker.OnScrollListener
                        .SCROLL_STATE_FLING:
                    break;
                case NumberPicker.OnScrollListener
                        .SCROLL_STATE_IDLE:
                    break;
                case NumberPicker.OnScrollListener
                        .SCROLL_STATE_TOUCH_SCROLL:
                    break;
            }
        }
    }

    //设置TimerPicker分割线的颜色和高度
    private void setNumberPickerDivider(Context context, NumberPicker numberPicker) {
        NumberPicker picker = numberPicker;
        Field[] pickerFields = NumberPicker.class.getDeclaredFields();
        for (Field pf : pickerFields) {
            if (pf.getName().equals("mSelectionDivider")) {  //设置颜色
                pf.setAccessible(true);
                ColorDrawable colorDrawable = new ColorDrawable(
                        ContextCompat.getColor(context, R.color.colorTransparent)); //选择自己喜欢的颜色
                try {
                    pf.set(numberPicker, colorDrawable);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
            if (pf.getName().equals("mSelectionDividerHeight")) {   //设置高度
                pf.setAccessible(true);
                try {
                    int result = 3;  //要设置的高度
                    pf.set(picker, result);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            }
            picker.invalidate();
        }
    }

}
