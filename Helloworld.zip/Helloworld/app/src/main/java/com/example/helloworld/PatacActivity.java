package com.example.helloworld;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.helloworld.patac.PatacDateTimePickerActivity;
import com.example.helloworld.patac.PatacInputBoxActivity;
import com.example.helloworld.patac.PatacListViewActivity;
import com.example.helloworld.patac.PatacNavigationBarActivity;
import com.example.helloworld.patac.PatacPageIndicatorActivity;
import com.example.helloworld.patac.PatacPickerActivity;
import com.example.helloworld.patac.PatacTabHostActivity;

public class PatacActivity extends AppCompatActivity {

    private Button mBtnListView;
    private Button mBtnTabHost;
    private Button mBtnNavigationBar;
    private Button mBtnPicker;
    private Button mBtnDateTimePicker;
    private Button mBtnPageIndicator;
    private Button mBtnInputbox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patac);

        mBtnListView = findViewById(R.id.btn_listview);
        mBtnTabHost = findViewById(R.id.btn_tabhost);
        mBtnNavigationBar = findViewById(R.id.btn_navigationbar);
        mBtnPicker = findViewById(R.id.btn_picker);
        mBtnDateTimePicker = findViewById(R.id.btn_date_time_picker);
        mBtnPageIndicator = findViewById(R.id.btn_pageindicator);
        mBtnInputbox = findViewById(R.id.btn_inputbox);

        setOnClickListener();
    }

    private void setOnClickListener(){
        OnClick onClick = new OnClick();
        mBtnListView.setOnClickListener(onClick);
        mBtnTabHost.setOnClickListener(onClick);
        mBtnNavigationBar.setOnClickListener(onClick);
        mBtnPicker.setOnClickListener(onClick);
        mBtnDateTimePicker.setOnClickListener(onClick);
        mBtnPageIndicator.setOnClickListener(onClick);
        mBtnInputbox.setOnClickListener(onClick);
    }

    class OnClick implements View.OnClickListener{

        @Override
        public void onClick(View v) {
            Intent intent = null;
            switch(v.getId()){
                case R.id.btn_listview:
                    intent = new Intent(PatacActivity.this, PatacListViewActivity.class);
                    break;
                case R.id.btn_tabhost:
                    intent = new Intent(PatacActivity.this, PatacTabHostActivity.class);
                    break;
                case R.id.btn_navigationbar:
                    intent = new Intent(PatacActivity.this, PatacNavigationBarActivity.class);
                    break;
                case R.id.btn_picker:
                    intent = new Intent(PatacActivity.this, PatacPickerActivity.class);
                    break;
                case R.id.btn_date_time_picker:
                    intent = new Intent(PatacActivity.this, PatacDateTimePickerActivity.class);
                    break;
                case R.id.btn_pageindicator:
                    intent = new Intent(PatacActivity.this, PatacPageIndicatorActivity.class);
                    break;
                case R.id.btn_inputbox:
                    intent = new Intent(PatacActivity.this, PatacInputBoxActivity.class);
                    break;
            }
            if(intent != null) {
                startActivity(intent);
            }
        }
    };
}
