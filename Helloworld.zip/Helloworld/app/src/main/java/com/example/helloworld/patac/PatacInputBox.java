package com.example.helloworld.patac;

import android.content.Context;
import android.graphics.Color;
import android.preference.EditTextPreference;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.helloworld.R;


public class PatacInputBox extends RelativeLayout {

    private EditText mEtContent;
    private TextView mTvNotice;

    public PatacInputBox(Context context) {
        super(context);
    }

    public PatacInputBox(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public PatacInputBox(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public PatacInputBox(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }

    private void init(Context context){
        LayoutInflater.from(context).inflate(R.layout.layout_patac_inputbox, this, true);
        mEtContent = findViewById(R.id.et_content);
        mTvNotice = findViewById(R.id.tv_notice);
    }

    public String getContent() {
        return mEtContent.getText().toString();
    }

    public void setContent(String content){
        mEtContent.setText(content);
    }

    public void setNotice(String notice){
        mTvNotice.setText(notice);
    }

    public void setErrorNotice(String notice){
        mTvNotice.setText(notice);
        mTvNotice.setTextColor(getResources().getColor(R.color.colorRed));
    }

    public void setDefaultHint(String hint){
        mEtContent.setHint(hint);
    }

    public void setHint(View v, boolean hasFocus){
        EditText editText = (EditText) v;
        String hint = null;
        if(hasFocus){
            hint = editText.getHint().toString();
            editText.setTag(hint);
            editText.setHint("");
        }else{
            hint = editText.getTag().toString();
            editText.setHint(hint);
        }
    }

    public void addTextChangedListener(TextWatcher watcher) {
        if (watcher != null) {
            mEtContent.addTextChangedListener(watcher);
        }
    }

    public void setOnFocusChangeListener(OnFocusChangeListener listener) {
        if(listener != null) {
            mEtContent.setOnFocusChangeListener(listener);
        }
    }

}
