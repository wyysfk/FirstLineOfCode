package com.example.helloworld.patac;

import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.example.helloworld.R;
import com.google.android.material.tabs.TabLayout;

public class PatacPageIndicatorActivity extends AppCompatActivity {

    private PatacFragmentPagerAdapter mAdapter;
    private ViewPager mVpPage;
    private TabLayout mTlTab;
    private ImageView mIv1, mIv2, mIv3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patac_page_indicator);

        mAdapter = new PatacFragmentPagerAdapter(getSupportFragmentManager());
        mVpPage = findViewById(R.id.pager);
        mTlTab = findViewById(R.id.tab);
        mIv1 = findViewById(R.id.iv_1);
        mIv2 = findViewById(R.id.iv_2);
        mIv3 = findViewById(R.id.iv_3);

        mVpPage.setAdapter(mAdapter);
        mTlTab.setupWithViewPager(mVpPage);
        mTlTab.setTabMode(TabLayout.MODE_FIXED);

        mVpPage.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                Log.d("onPageSelected", "position="+position);
                switch (position){
                    case 0:
                        mIv1.setImageResource(R.drawable.patac_btn_pageindicator_selected_u560_selected);
                        mIv2.setImageResource(R.drawable.patac_btn_pageindicator_selected_u560);
                        mIv3.setImageResource(R.drawable.patac_btn_pageindicator_selected_u560);
                        break;
                    case 1:
                        mIv1.setImageResource(R.drawable.patac_btn_pageindicator_selected_u560);
                        mIv2.setImageResource(R.drawable.patac_btn_pageindicator_selected_u560_selected);
                        mIv3.setImageResource(R.drawable.patac_btn_pageindicator_selected_u560);
                        break;
                    case 2:
                        mIv1.setImageResource(R.drawable.patac_btn_pageindicator_selected_u560);
                        mIv2.setImageResource(R.drawable.patac_btn_pageindicator_selected_u560);
                        mIv3.setImageResource(R.drawable.patac_btn_pageindicator_selected_u560_selected);
                        break;
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }
}
