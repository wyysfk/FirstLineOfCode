package com.example.helloworld.patac;

import android.content.Context;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.widget.ListAdapter;
import android.widget.ListView;

//使用SwipelistLayout实现
public class PatacListView3 extends ListView {

    public PatacListView3(Context context) {
        super(context);
        init(context);
    }

    public PatacListView3(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public PatacListView3(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    public PatacListView3(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init(context);
    }

    private void init(Context context){

    }

    @Override
    public void setAdapter(ListAdapter adapter) {
        super.setAdapter(adapter);
    }

    public void scrollTo(int position){

    }

}
