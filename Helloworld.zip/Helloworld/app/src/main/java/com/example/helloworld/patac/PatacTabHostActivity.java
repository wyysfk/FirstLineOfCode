package com.example.helloworld.patac;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TabHost;
import android.widget.TextView;

import com.example.helloworld.R;

public class PatacTabHostActivity extends AppCompatActivity {

    private TabHost mPatacTabHost;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patac_tab_host);
        mPatacTabHost = findViewById(android.R.id.tabhost);
        mPatacTabHost.setup();

        View view1 = getLayoutInflater().inflate(R.layout.layout_patac_tab, null);
        TextView tvTabTitle1 = view1.findViewById(R.id.tv_tab_title);
        tvTabTitle1.setText("电话");
        TabHost.TabSpec tab1 = mPatacTabHost.newTabSpec("tab1")
                .setIndicator(view1).setContent(R.id.tv_one);
        mPatacTabHost.addTab(tab1);

        View view2 = getLayoutInflater().inflate(R.layout.layout_patac_tab, null);
        TextView tvTabTitle2 = view2.findViewById(R.id.tv_tab_title);
        tvTabTitle2.setText("媒体");
        TabHost.TabSpec tab2 = mPatacTabHost.newTabSpec("tab2")
                .setIndicator(view2).setContent(R.id.tv_two);
        mPatacTabHost.addTab(tab2);

        View view3 = getLayoutInflater().inflate(R.layout.layout_patac_tab, null);
        TextView tvTabTitle3 = view3.findViewById(R.id.tv_tab_title);
        tvTabTitle3.setText("蓝牙");
        TabHost.TabSpec tab3 = mPatacTabHost.newTabSpec("tab3")
                .setIndicator(view3).setContent(R.id.tv_three);
        mPatacTabHost.addTab(tab3);
    }
}
