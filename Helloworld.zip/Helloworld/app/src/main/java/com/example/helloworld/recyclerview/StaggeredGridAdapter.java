package com.example.helloworld.recyclerview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.helloworld.R;

public class StaggeredGridAdapter extends RecyclerView.Adapter<StaggeredGridAdapter.LinearViewHolder> {

    private Context mContext;
    private OnItemClickListener mListener;

    public StaggeredGridAdapter(Context context, OnItemClickListener listener) {
        this.mContext = context;
        this.mListener = listener;
    }

    @NonNull
    @Override
    public StaggeredGridAdapter.LinearViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new LinearViewHolder(LayoutInflater.from(mContext).inflate(R.layout.layout_staggered_grid_recyclerview_item, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull StaggeredGridAdapter.LinearViewHolder holder, final int position) {
//        if (position % 2 != 0) {
//            holder.imageView.setImageResource(R.drawable.image1);
//        } else {
//            holder.imageView.setImageResource(R.drawable.image2);
//        }

        int i = position % 10;
        switch (i) {
            case 0:
                holder.imageView.setImageResource(R.drawable.image1);
                break;
            case 1:
                holder.imageView.setImageResource(R.drawable.image2);
                break;
            case 2:
                holder.imageView.setImageResource(R.drawable.image3);
                break;
            case 3:
                holder.imageView.setImageResource(R.drawable.image4);
                break;
            case 4:
                holder.imageView.setImageResource(R.drawable.image5);
                break;
            case 5:
                holder.imageView.setImageResource(R.drawable.image6);
                break;
            case 6:
                holder.imageView.setImageResource(R.drawable.image7);
                break;
            case 7:
                holder.imageView.setImageResource(R.drawable.image8);
                break;
            case 8:
                holder.imageView.setImageResource(R.drawable.image9);
                break;
            case 9:
                holder.imageView.setImageResource(R.drawable.image10);
                break;
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Toast.makeText(mContext, "click..." + position, Toast.LENGTH_SHORT).show();
                mListener.onClick(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return 30;
    }

    class LinearViewHolder extends RecyclerView.ViewHolder {

        private ImageView imageView;

        public LinearViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.iv);
        }
    }

    public interface OnItemClickListener {
        void onClick(int pos);
    }
}
