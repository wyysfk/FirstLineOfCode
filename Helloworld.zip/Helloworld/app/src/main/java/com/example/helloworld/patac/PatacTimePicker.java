package com.example.helloworld.patac;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.ColorDrawable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.TimePicker;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.load.engine.Resource;
import com.example.helloworld.R;

import java.lang.reflect.Field;
import java.util.Locale;

public class PatacTimePicker extends LinearLayout {

//    private static final String TAG = "CustomTimePicker";
//
//    public PatacTimePicker(Context context, AttributeSet attrs)
//    {
//        super(context, attrs);
//        Log.d("PatacTimePicker","---PatacTimePicker---");
//
//        Class<?> idClass = null;
//        Class<?> numberPickerClass = null;
//        Field selectionDividerField = null;
//        Field hourField = null;
//        Field minuteField = null;
//        Field amPmField = null;
//        NumberPicker hourNumberPicker = null;
//        NumberPicker minuteNumberPicker = null;
//        NumberPicker amPmNumberPicker = null;
//
//        try
//        {
//            Resources systemResources = Resources.getSystem();
//            int hourNumberPickerId = systemResources.getIdentifier("hour", "id", "android");
//            int minuteNumberPickerId = systemResources.getIdentifier("minute", "id", "android");
//            int amPmNumberPickerId = systemResources.getIdentifier("amPm", "id", "android");
//            hourNumberPicker = (NumberPicker) findViewById(hourNumberPickerId);
//            minuteNumberPicker = (NumberPicker) findViewById(minuteNumberPickerId);
//            amPmNumberPicker = (NumberPicker) findViewById(amPmNumberPickerId);
//            hourNumberPicker.setBackgroundColor(getResources().getColor(R.color.colorAccent));
//            amPmNumberPicker.setDisplayedValues(new String[]{"AA","BB","CC"});
//
////            // Create an instance of the id class
////            idClass = Class.forName("com.android.internal.R$id");
////
////            // Get the fields that store the resource IDs for the hour, minute and amPm NumberPickers
////            hourField = idClass.getField("hour");
////            minuteField = idClass.getField("minute");
////            amPmField = idClass.getField("amPm");
////
////            // Use the resource IDs to get references to the hour, minute and amPm NumberPickers
////            hourNumberPicker = (NumberPicker) findViewById(hourField.getInt(null));
////            minuteNumberPicker = (NumberPicker) findViewById(minuteField.getInt(null));
////            amPmNumberPicker = (NumberPicker) findViewById(amPmField.getInt(null));
//
//            numberPickerClass = Class.forName("android.widget.NumberPicker");
//
//            // Set the value of the mSelectionDivider field in the hour, minute and amPm NumberPickers
//            // to refer to our custom drawables
//            selectionDividerField = numberPickerClass.getDeclaredField("mSelectionDivider");
//            selectionDividerField.setAccessible(true);
//            selectionDividerField.set(hourNumberPicker, getResources().getDrawable(R.drawable.selection_divider));
//            selectionDividerField.set(minuteNumberPicker, getResources().getDrawable(R.drawable.selection_divider));
//            selectionDividerField.set(amPmNumberPicker, getResources().getDrawable(R.drawable.selection_divider));
//        }
//        catch (ClassNotFoundException e)
//        {
//            Log.e(TAG, "ClassNotFoundException in CustomTimePicker", e);
//        }
//        catch (NoSuchFieldException e)
//        {
//            Log.e(TAG, "NoSuchFieldException in CustomTimePicker", e);
//        }
//        catch (IllegalAccessException e)
//        {
//            Log.e(TAG, "IllegalAccessException in CustomTimePicker", e);
//        }
//        catch (IllegalArgumentException e)
//        {
//            Log.e(TAG, "IllegalArgumentException in CustomTimePicker", e);
//        }
//    }

    private NumberPicker mNpHour, mNpMinute, mNpAmpm;

    public PatacTimePicker(Context context) {
        super(context);
        init(context);
    }

    public PatacTimePicker(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public PatacTimePicker(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    public PatacTimePicker(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init(context);
    }

    private void init(Context context){
        LayoutInflater.from(context).inflate(R.layout.layout_patac_time_picker, this, true);
        mNpHour = findViewById(R.id.np_houre);
        mNpMinute = findViewById(R.id.np_minute);
        mNpAmpm = findViewById(R.id.np_ampm);

        MyFormatter myFormatter = new MyFormatter();
        OnValueChangeListener valueChangeListener = new OnValueChangeListener();
        OnScrollStateChange scrollStateChange = new OnScrollStateChange();

        mNpHour.setMinValue(1);
        mNpHour.setMaxValue(12);
        mNpHour.setFormatter(myFormatter);
        mNpHour.setOnValueChangedListener(valueChangeListener);
        mNpHour.setOnScrollListener(scrollStateChange);

        mNpMinute.setMinValue(1);
        mNpMinute.setMaxValue(59);
        mNpMinute.setFormatter(myFormatter);
        mNpMinute.setOnValueChangedListener(valueChangeListener);
        mNpMinute.setOnScrollListener(scrollStateChange);

        mNpAmpm.setMinValue(0);
        mNpAmpm.setMaxValue(1);

        Locale locale = context.getResources().getConfiguration().locale;
        String language = locale.getLanguage();
        Log.d("PatacTimePicker","language=" + language);
        if(language.contains("zh")){
            mNpAmpm.setDisplayedValues(new String[]{"上午","下午"});
        }else{
            mNpAmpm.setDisplayedValues(new String[]{"AM","PM"});
        }

        mNpAmpm.setOnValueChangedListener(valueChangeListener);
        mNpAmpm.setOnScrollListener(scrollStateChange);

        //设置分割线的颜色和高度
        setNumberPickerDivider(context, mNpHour);
        setNumberPickerDivider(context, mNpMinute);
        setNumberPickerDivider(context, mNpAmpm);

        //设置点击事件不弹键盘
        setDescendantFocusability(FOCUS_BLOCK_DESCENDANTS);
    }

    class MyFormatter implements NumberPicker.Formatter{

        @Override
        public String format(int value) {
            String tmpStr = String.valueOf(value);
            if(value < 10){
                tmpStr = "0" + tmpStr;
            }
            return tmpStr;
        }
    }

    class OnValueChangeListener implements NumberPicker.OnValueChangeListener{

        @Override
        public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
            switch (picker.getId()){
                case R.id.np_houre:
                    Log.d("onValueChange", "houre oldVal="+oldVal+",newVal="+newVal);
                    break;
                case R.id.np_minute:
                    Log.d("onValueChange", "minute oldVal="+oldVal+",newVal="+newVal);
                    break;
                case R.id.np_ampm:
                    Log.d("onValueChange", "ampm oldVal="+oldVal+",newVal="+newVal);
                    break;
            }
        }
    }

    class OnScrollStateChange implements NumberPicker.OnScrollListener{

        @Override
        public void onScrollStateChange(NumberPicker view, int scrollState) {
            switch (scrollState){
                case NumberPicker.OnScrollListener
                        .SCROLL_STATE_FLING:
                    break;
                case NumberPicker.OnScrollListener
                        .SCROLL_STATE_IDLE:
                    break;
                case NumberPicker.OnScrollListener
                        .SCROLL_STATE_TOUCH_SCROLL:
                    break;
            }
        }
    }

    //设置TimerPicker分割线的颜色和高度
    private void setNumberPickerDivider(Context context, NumberPicker numberPicker) {
        NumberPicker picker = numberPicker;
        Field[] pickerFields = NumberPicker.class.getDeclaredFields();
        for (Field pf : pickerFields) {
            if (pf.getName().equals("mSelectionDivider")) {  //设置颜色
                pf.setAccessible(true);
                ColorDrawable colorDrawable = new ColorDrawable(
                        ContextCompat.getColor(context, R.color.colorTransparent)); //选择自己喜欢的颜色
                try {
                    pf.set(numberPicker, colorDrawable);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
            if (pf.getName().equals("mSelectionDividerHeight")) {   //设置高度
                pf.setAccessible(true);
                try {
                    int result = 3;  //要设置的高度
                    pf.set(picker, result);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            }
            picker.invalidate();
        }
    }

}
