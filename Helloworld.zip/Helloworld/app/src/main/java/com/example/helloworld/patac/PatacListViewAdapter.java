package com.example.helloworld.patac;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.helloworld.R;

import java.util.ArrayList;

public class PatacListViewAdapter extends BaseAdapter {

    private Context mContext;
    private LayoutInflater mLayoutInflater;
    private ArrayList<String> mListContent;
    private int mRemovePosition;

    public PatacListViewAdapter(Context context, ArrayList<String> listContent){
        mContext = context;
        mLayoutInflater = LayoutInflater.from(context);
        mListContent = listContent;
    }

    @Override
    public int getCount() {
        return mListContent.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        if(convertView == null){
            //pataclistview1
            convertView = mLayoutInflater.inflate(R.layout.layout_patac_list_item, null);
            //pataclistview3
            //convertView = mLayoutInflater.inflate(R.layout.layout_patac_swipe_list_item, null);
            holder = new ViewHolder();
            holder.tvContent = convertView.findViewById(R.id.tv_content);
            holder.imageView1 = convertView.findViewById(R.id.iv_1);
            holder.imageView2 = convertView.findViewById(R.id.iv_2);
            convertView.setTag(holder);
        }else{
            holder = (ViewHolder) convertView.getTag();
        }

        //给控件赋值
        holder.tvContent.setText(mListContent.get(position));

        return convertView;
    }

    public void remove(int position){
        mRemovePosition = position;
//        new Thread(new Runnable() {
//            @Override
//            public void run() {
//                mListContent.remove(mRemovePosition);
//            }
//        });
    }

    static class ViewHolder{
        TextView tvContent;
        ImageView imageView1, imageView2;
    };
}
