package com.example.helloworld.patac;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.ColorDrawable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.example.helloworld.R;

import org.w3c.dom.Text;

import java.lang.reflect.Field;
import java.util.Calendar;
import java.util.Locale;

public class PatacDateTimePicker extends LinearLayout
{
    private PatacDatePicker2 mPatacDatePicker2;
    private PatacTimePicker mPatacTimePicker;

    public PatacDateTimePicker(Context context) {
        super(context);
        init(context);
    }

    public PatacDateTimePicker(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public PatacDateTimePicker(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    public PatacDateTimePicker(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init(context);
    }

    private void init(Context context){
        LayoutInflater.from(context).inflate(R.layout.layout_patac_date_time_picker, this, true);
        mPatacDatePicker2 = findViewById(R.id.patac_date_picker2);
        mPatacTimePicker = findViewById(R.id.patac_time_picker);

        Locale locale = context.getResources().getConfiguration().locale;
        String language = locale.getLanguage();
        boolean isChina = false;
        Log.d("PatacDateTimePicker","language=" + language);
        if(language.contains("zh")){
            isChina = true;
        }

        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH) + 1;
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        Log.d("PatacDateTimePicker", "年："+year+" 月："+month+" 日："+day);

        MyFormatter myFormatter = new MyFormatter();
        OnValueChangeListener valueChangeListener = new OnValueChangeListener();
        OnScrollStateChange scrollStateChange = new OnScrollStateChange();

        setNumberPickerAttribute(context);

        //设置点击事件不弹键盘
        setDescendantFocusability(FOCUS_BLOCK_DESCENDANTS);

    }

    class MyFormatter implements NumberPicker.Formatter{

        @Override
        public String format(int value) {
            String tmpStr = String.valueOf(value);
            if(value < 10){
                tmpStr = "0" + tmpStr;
            }
            return tmpStr;
        }
    }

    class OnValueChangeListener implements NumberPicker.OnValueChangeListener{

        @Override
        public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
            switch (picker.getId()){
                case R.id.np_houre:
                    Log.d("onValueChange", "houre oldVal="+oldVal+",newVal="+newVal);
                    break;
                case R.id.np_minute:
                    Log.d("onValueChange", "minute oldVal="+oldVal+",newVal="+newVal);
                    break;
                case R.id.np_ampm:
                    Log.d("onValueChange", "ampm oldVal="+oldVal+",newVal="+newVal);
                    break;
            }
        }
    }

    class OnScrollStateChange implements NumberPicker.OnScrollListener{

        @Override
        public void onScrollStateChange(NumberPicker view, int scrollState) {
            switch (scrollState){
                case NumberPicker.OnScrollListener
                        .SCROLL_STATE_FLING:
                    break;
                case NumberPicker.OnScrollListener
                        .SCROLL_STATE_IDLE:
                    break;
                case NumberPicker.OnScrollListener
                        .SCROLL_STATE_TOUCH_SCROLL:
                    break;
            }
        }
    }

    //设置NumberPicker属性，修改宽高等
    private void setNumberPickerAttribute(Context context){
        Log.d("PatacDateTimePicker", "packagename=" + context.getPackageName());
        Resources systemResources = Resources.getSystem();
        int yearNumberPickerId = systemResources.getIdentifier("year", "id", "android");
        int monthNumberPickerId = systemResources.getIdentifier("month", "id", "android");
        int dayNumberPickerId = systemResources.getIdentifier("day", "id", "android");
        Log.d("PatacDateTimePicker", "yearid=" + yearNumberPickerId +" monthid="
                + monthNumberPickerId +" dayid="+ dayNumberPickerId);

        NumberPicker yearNumberPicker = (NumberPicker) findViewById(yearNumberPickerId);
        NumberPicker monthNumberPicker = (NumberPicker) findViewById(monthNumberPickerId);
        NumberPicker dayNumberPicker = (NumberPicker) findViewById(dayNumberPickerId);
        resizeNumberPicker(yearNumberPicker, 0);
        resizeNumberPicker(monthNumberPicker, 0);
        resizeNumberPicker(dayNumberPicker, 0);

        Resources resources = context.getResources();
        int hourNumberPickerId = resources.getIdentifier("np_houre", "id", "com.example.helloworld");
        int minuteNumberPickerId = resources.getIdentifier("np_minute", "id", "com.example.helloworld");
        int ampmNumberPickerId = resources.getIdentifier("np_ampm", "id", "com.example.helloworld");
        int colonTextViewId = resources.getIdentifier("tv_colon", "id", "com.example.helloworld");
        Log.d("PatacDateTimePicker", "hourid=" + hourNumberPickerId +" minuteid=" + minuteNumberPickerId
                +" ampmid="+ ampmNumberPickerId + "colonid" + colonTextViewId);

        NumberPicker hourNumberPicker = (NumberPicker) findViewById(hourNumberPickerId);
        NumberPicker minuteNumberPicker = (NumberPicker) findViewById(minuteNumberPickerId);
        NumberPicker ampmNumberPicker = (NumberPicker) findViewById(ampmNumberPickerId);
        TextView colonTextView = findViewById(colonTextViewId);

        resizeNumberPicker(hourNumberPicker, 1);
        resizeNumberPicker(minuteNumberPicker, 1);
        resizeNumberPicker(ampmNumberPicker, 1);
        resizeTextView(colonTextView);
    }

    //设置TimerPicker分割线的颜色和高度
    private void setNumberPickerDivider(Context context, NumberPicker numberPicker) {
        NumberPicker picker = numberPicker;
        Field[] pickerFields = NumberPicker.class.getDeclaredFields();
        for (Field pf : pickerFields) {
            if (pf.getName().equals("mSelectionDivider")) {  //设置颜色
                pf.setAccessible(true);
                ColorDrawable colorDrawable = new ColorDrawable(
                        ContextCompat.getColor(context, R.color.colorTransparent)); //选择自己喜欢的颜色
                try {
                    pf.set(numberPicker, colorDrawable);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
            if (pf.getName().equals("mSelectionDividerHeight")) {   //设置高度
                pf.setAccessible(true);
                try {
                    int result = 3;  //要设置的高度
                    pf.set(picker, result);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            }
            picker.invalidate();
        }
    }

    //type:0  Date, 1 time
    private void resizeNumberPicker(NumberPicker np, int type){
        if(np != null) {
            if(type == 0) {
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(80, LayoutParams.WRAP_CONTENT);
                params.setMargins(15, 20, 10, 0);
                np.setLayoutParams(params);
            }else{
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(80, LayoutParams.WRAP_CONTENT);
                params.setMargins(15, 0, 10, 0);
                np.setLayoutParams(params);
            }
        }else{
            Log.d("PatacDateTimePicker","resizeNumberPicker np is null !!!");
        }
    }

    private void resizeTextView(TextView tv){
        if(tv != null){
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(40, LayoutParams.WRAP_CONTENT);
            params.setMargins(30, 195, 0, 0);
            tv.setTextSize(20);
            tv.setLayoutParams(params);
        }
    }
}
