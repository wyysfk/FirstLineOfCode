package com.example.helloworld.patac;

import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import android.widget.NumberPicker;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.example.helloworld.R;

import java.lang.reflect.Field;
import java.util.Locale;

public class PatacDefaultPicker extends LinearLayout {

    private NumberPicker mNpDefault;

    public PatacDefaultPicker(Context context) {
        super(context);
        init(context);
    }

    public PatacDefaultPicker(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public PatacDefaultPicker(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    public PatacDefaultPicker(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init(context);
    }

    private void init(Context context){
        LayoutInflater.from(context).inflate(R.layout.layout_patac_default_picker, this, true);
        mNpDefault = findViewById(R.id.np_default);

        OnValueChangeListener valueChangeListener = new OnValueChangeListener();
        OnScrollStateChange scrollStateChange = new OnScrollStateChange();
        String []str = {"XX","XX","XX"};

        mNpDefault.setMinValue(0);
        mNpDefault.setMaxValue(2);
        mNpDefault.setDisplayedValues(str);
        mNpDefault.setValue(1);
        mNpDefault.setOnValueChangedListener(valueChangeListener);
        mNpDefault.setOnScrollListener(scrollStateChange);

        //设置分割线的颜色和高度
        setNumberPickerDivider(context, mNpDefault);

        //设置点击事件不弹键盘
        setDescendantFocusability(FOCUS_BLOCK_DESCENDANTS);
    }

    class MyFormatter implements NumberPicker.Formatter{

        @Override
        public String format(int value) {
            String tmpStr = String.valueOf(value);
            if(value < 10){
                tmpStr = "0" + tmpStr;
            }
            return tmpStr;
        }
    }

    class OnValueChangeListener implements NumberPicker.OnValueChangeListener{

        @Override
        public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
            switch (picker.getId()){
                case R.id.np_houre:
                    Log.d("onValueChange", "oldVal="+oldVal+",newVal="+newVal);
                    break;
            }
        }
    }

    class OnScrollStateChange implements NumberPicker.OnScrollListener{

        @Override
        public void onScrollStateChange(NumberPicker view, int scrollState) {
            switch (scrollState){
                case NumberPicker.OnScrollListener
                        .SCROLL_STATE_FLING:
                    break;
                case NumberPicker.OnScrollListener
                        .SCROLL_STATE_IDLE:
                    break;
                case NumberPicker.OnScrollListener
                        .SCROLL_STATE_TOUCH_SCROLL:
                    break;
            }
        }
    }

    //设置TimerPicker分割线的颜色和高度
    private void setNumberPickerDivider(Context context, NumberPicker numberPicker) {
        NumberPicker picker = numberPicker;
        Field[] pickerFields = NumberPicker.class.getDeclaredFields();
        for (Field pf : pickerFields) {
            if (pf.getName().equals("mSelectionDivider")) {  //设置颜色
                pf.setAccessible(true);
                ColorDrawable colorDrawable = new ColorDrawable(
                        ContextCompat.getColor(context, R.color.colorTransparent)); //选择自己喜欢的颜色
                try {
                    pf.set(numberPicker, colorDrawable);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
            if (pf.getName().equals("mSelectionDividerHeight")) {   //设置高度
                pf.setAccessible(true);
                try {
                    int result = 3;  //要设置的高度
                    pf.set(picker, result);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            }
            picker.invalidate();
        }
    }

}
