package com.example.helloworld.patac;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Toast;

import com.example.helloworld.R;

import java.util.ArrayList;

public class PatacListViewActivity extends AppCompatActivity implements PatacListView1.RemoveListener {

    private PatacListView1 mPatacListView1;
    private ArrayList<String> mListContent;
    private PatacListViewAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patac_list_view);
        init();
    }

    private void init() {
        mPatacListView1 = findViewById(R.id.pataclistview);
        mPatacListView1.setRemoveListener(this);

        initListContent();
        mAdapter = new PatacListViewAdapter(PatacListViewActivity.this, mListContent);
        mPatacListView1.setAdapter(mAdapter);
        mPatacListView1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(PatacListViewActivity.this, "点击 pos"+position, Toast.LENGTH_SHORT).show();
            }
        });
    }

    void initListContent(){
        mListContent = new ArrayList<String>();
        for(int i = 0; i < 30; i++){
            mListContent.add("Line " + i);
        }
    }

    @Override
    public void removeItem(PatacListView1.RemoveDirection direction, int position) {
        //mAdapter.remove(position);
        mListContent.remove(position);
        switch (direction){
            case RIGHT:
                Toast.makeText(PatacListViewActivity.this, "向右删除"+position, Toast.LENGTH_SHORT).show();
                break;
            case LEFT:
                Toast.makeText(PatacListViewActivity.this, "向左删除"+position, Toast.LENGTH_SHORT).show();
                break;
        }
    }
}
