package com.example.helloworld.patac;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;

import com.example.helloworld.R;

public class PatacNavigationBarActivity extends Activity {
    private PatacNavigationBar mPatacNavigationBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patac_navigation_bar);
        mPatacNavigationBar = findViewById(R.id.title_pnb);
        mPatacNavigationBar.setActivity(this);
    }
}
