package com.example.helloworld.patac;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.TabHost;

public class PatacTabHost extends TabHost {
    public PatacTabHost(Context context) {
        super(context);
    }

    public PatacTabHost(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public PatacTabHost(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public PatacTabHost(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }
}
