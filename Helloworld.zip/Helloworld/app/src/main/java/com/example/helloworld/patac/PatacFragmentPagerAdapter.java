package com.example.helloworld.patac;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

public class PatacFragmentPagerAdapter extends FragmentPagerAdapter {
    private int mCount = 3;

    public PatacFragmentPagerAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {
        return PatacFragmentA.newInstance("Page"+position);
    }

    @Override
    public int getCount() {
        return mCount;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return "PAGE" + position;
    }
}
