package com.example.helloworld.patac;

import android.app.Activity;
import android.content.Context;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.example.helloworld.R;

import java.security.Key;

public class PatacNavigationBar extends LinearLayout {
    private Button mBtnBack;
    private TextView mTvTitle;
    private ImageView mIvIcon;
    private Activity mActivity;

    public PatacNavigationBar(Context context) {
        super(context);
    }

    public PatacNavigationBar(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public PatacNavigationBar(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    public PatacNavigationBar(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init(context);
    }

    private void init(final Context context){
        LayoutInflater.from(context).inflate(R.layout.layout_patac_navigation_bar, this, true);
        mBtnBack = findViewById(R.id.btn_back);
        mTvTitle = findViewById(R.id.tv_title);
        mIvIcon = findViewById(R.id.iv_icon);
    }

    public void setTvTitle(String title){
        if(mTvTitle != null) {
            mTvTitle.setText(title);
        }
    }

    public void setTvTitle(int resId){
        if (mTvTitle != null) {
            mTvTitle.setText(resId);
        }
    }

    public void setIvIconSrc(int resId){
        if (mIvIcon != null) {
            mIvIcon.setImageResource(resId);
        }
    }

    public void setActivity(Activity activity){
        mActivity = activity;
        mBtnBack.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                mActivity.finish();
            }
        });
    }
}
