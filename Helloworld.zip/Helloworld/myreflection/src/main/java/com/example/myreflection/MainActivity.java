package com.example.myreflection;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Shader;
import android.os.Bundle;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    ImageView imageView1, imageView2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        initViews1();

//        initViews2();

        initViews3();
    }

    //方式1
    private void initViews1() {
        imageView1 = (ImageView) findViewById(R.id.imageView1);
        imageView2 = (ImageView) findViewById(R.id.imageView2);
        Bitmap bm = BitmapFactory.decodeResource(getResources(), R.drawable.desert);
        imageView1.setImageBitmap(bm);
        Bitmap modBm = Bitmap.createBitmap(bm.getWidth(), bm.getHeight(), bm.getConfig());
        Canvas canvas = new Canvas(modBm);
        Paint paint = new Paint();
        paint.setColor(Color.BLACK);
        paint.setAntiAlias(true);
        Matrix matrix = new Matrix();
        //matrix.setRotate(90, bm.getWidth()/2, bm.getHeight()/2);
        //matrix.setTranslate(20, 20);
        //镜子效果
        matrix.setScale(1, -1);
        matrix.postTranslate(0, bm.getHeight());
        canvas.drawBitmap(bm, matrix, paint);
        imageView2.setImageBitmap(modBm);
    }

    //方式2
    private void initViews2() {
        imageView1 = (ImageView) findViewById(R.id.imageView1);
        imageView2 = (ImageView) findViewById(R.id.imageView2);
        Bitmap bm1 = BitmapFactory.decodeResource(getResources(), R.drawable.desert);
        imageView1.setImageBitmap(bm1);

        Bitmap bm2 = getReflectionPic(R.drawable.desert);
        imageView2.setImageBitmap(bm2);
    }

    /**
     * 实现倒影图片显示
     *
     * @param imgId 目标图片id
     * @return 倒影图片
     */
    public Bitmap getReflectionPic(int imgId) {
        //创建资源Bitmap
        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), imgId);
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        //定义原图与倒影间的间距
        int spac = 10;

        //绘制原图的下一半图片
        Matrix matrix = new Matrix();
        //倒影翻转
        matrix.setScale(1, -1);
        //创建反方向Bitmap，并定义倒影高度
        Bitmap reflectionPic = Bitmap.createBitmap(bitmap, 0, height / 2, width, height / 2, matrix, false);
        //合成图片
        Bitmap benchmarkBitmap = Bitmap.createBitmap(width, height + height / 2 + 60, Bitmap.Config.ARGB_8888);
        //以合成图片为画布
        Canvas canvas = new Canvas(benchmarkBitmap);
        //将原图与倒影图片画在一张图上
        canvas.drawBitmap(bitmap, 0, 0, null);
        canvas.drawBitmap(reflectionPic, 0, height + spac, null);
        //添加遮罩
        Paint paint = new Paint();
        //创建线性渐变；color1:渐变色的起始颜色  color2：终止颜色
        LinearGradient linearGradient = new LinearGradient(0, height + spac, 0,
                benchmarkBitmap.getHeight(), Color.BLACK, Color.TRANSPARENT, Shader.TileMode.MIRROR);
//                benchmarkBitmap.getHeight(), Color.BLACK, Color.BLUE, Shader.TileMode.MIRROR);
        paint.setShader(linearGradient);
        //这里取矩形渐变区和图片的交集
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        canvas.drawRect(0, height , width, benchmarkBitmap.getHeight()+ spac, paint);
        return benchmarkBitmap;
    }

    //方式3
    private void initViews3() {
        imageView1 = (ImageView) findViewById(R.id.imageView1);
        imageView2 = (ImageView) findViewById(R.id.imageView2);
        Bitmap bm1 = BitmapFactory.decodeResource(getResources(), R.drawable.desert);
        imageView1.setImageBitmap(bm1);

        Bitmap bm2 = createReflectedImage(bm1);
        imageView2.setImageBitmap(bm2);
    }

    /**
     * 获取带倒影的bitmap，生成的图片高度 = 原图高度 + 间隙高度 + 倒影图片高度（原图的1/2）
     *
     * @param originalImage
     * @return
     */
    public static Bitmap createReflectedImage(Bitmap originalImage) {
        // 原图和倒影之间的间隙宽度
        final int reflectionGap = 8;
        int width = originalImage.getWidth();
        int height = originalImage.getHeight();
        // 使图片上下颠倒的matrix参数
        Matrix matrix = new Matrix();
        matrix.preScale(1, -1);
        // 创建倒影图片，原图的下半部，且上下颠倒
        Bitmap reflectionImage = Bitmap.createBitmap(originalImage, 0, height / 2, width,
                height / 2, matrix, false);
        // 创建带倒影图片的“易变的”bitmap（可以理解为图片的框架），总是推荐使用参数Config.ARGB_8888（每个像素32位）
        Bitmap bitmapWithReflection = Bitmap.createBitmap(width, (height + height / 2),
                Bitmap.Config.ARGB_8888);
        // 使用易变的bitmap创建画布
        Canvas canvas = new Canvas(bitmapWithReflection);
        // 将原始图片绘制到画布上
        canvas.drawBitmap(originalImage, 0, 0, null);
        Paint defaultPaint = new Paint();
        defaultPaint.setColor(Color.TRANSPARENT);
        // 画原图和倒影之间的间隙
        canvas.drawRect(0, height, width, height + reflectionGap, defaultPaint);
        // 画图片的倒影
        canvas.drawBitmap(reflectionImage, 0, height + reflectionGap, null);
        Paint paint = new Paint();
        // 渐变效果
        LinearGradient shader = new LinearGradient(0, originalImage.getHeight(), 0,
                bitmapWithReflection.getHeight() + reflectionGap, 0x70ffffff, 0x00ffffff,
                Shader.TileMode.CLAMP);
        paint.setShader(shader);
        // Mode.DST_IN为先后绘制的图层的交集，后绘制的图层在上，这里两个图层完全重合，实际上就是渐变遮罩效果
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        // 将渐变遮罩绘制到画布上，覆盖范围：间隙和倒影
        canvas.drawRect(0, height, width, bitmapWithReflection.getHeight()
                + reflectionGap, paint);
        return bitmapWithReflection;
    }
}