package com.example.mylayout;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;

public class DateInfoConstaint extends ConstraintLayout {
    private final static String TAG = "DateInfoConstaint";
    private static final boolean DEBUG_DRAWING_TIME = true;

    private static final float REFLECTION_SIZE = 2.0f;
    /* Drawing tools used to create the reflection pool effect. */
    private final Paint mDarkPaint = new Paint();
    private final Paint mReflectionPaint = new Paint();
    private final Shader mShader;
    private Matrix mMatrix = new Matrix();

    public DateInfoConstaint(@NonNull Context context) {
        this(context, null);
        Log.i(TAG, "DateInfoConstaint: 1");
    }

    public DateInfoConstaint(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
        Log.i(TAG, "DateInfoConstaint: 2");
    }

    public DateInfoConstaint(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        this(context, attrs, defStyleAttr, 0);
        Log.i(TAG, "DateInfoConstaint: 3");
    }

    public DateInfoConstaint(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
//        inflate(context, R.layout.date_info_constraint, null);
        LayoutInflater.from(getContext()).inflate(R.layout.date_info_constraint, this);
        Log.i(TAG, "DateInfoConstaint: 4");

        //如果用自定义的view，重写ondraw()应该将调用此方法设置为false，这样程序会调用自定义的布局
        setWillNotDraw(false);

        mDarkPaint.setColor(0x98000000);

        //用来实现线性渐变效果
        //第一个参数为线性起点的x坐标,第二个参数为线性起点的y坐标
        //第三个参数为线性终点的x坐标,第四个参数为线性终点的y坐标
        //color0表示渐变起始颜色,color1表示渐变终止颜色
        //第七个参数为渲染器平铺的模式
        mShader = new LinearGradient(0, 0, 0, 1, 0x70ffffff, 0x00ffffff, Shader.TileMode.MIRROR);
//        mShader = new LinearGradient(0, 0, 0, 1, 0xa0ffffff, 0x00000000, Shader.TileMode.MIRROR);
        mReflectionPaint.setShader(mShader);
        mReflectionPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        mMatrix.preScale(1, -1);
    }

    @Override
    protected void onMeasure(int wspec, int hspec) {
        super.onMeasure(wspec, hspec);
        Log.i(TAG, "onMeasure");

        if (getChildCount() > 0) {
            Log.i(TAG, "onMeasure: child > 0");
            View child = getChildAt(0);

            int childw = child.getMeasuredWidth();
            int childh = child.getMeasuredHeight();
            Log.i(TAG, "onMeasure: childw=" + childw + " childh=" + childh);
            /* Enlarge the child's height by 33% for the reflection. */
            setMeasuredDimension(resolveSize(childw, wspec), resolveSize((int) (childh * REFLECTION_SIZE), hspec));
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        Log.i(TAG, "onDraw");
        long now;
        if (DEBUG_DRAWING_TIME) {
            now = System.currentTimeMillis();
        }
        /* Magic magic magic... */
        if (getChildCount() > 0) {
            drawReflection(canvas);
        }

        if (DEBUG_DRAWING_TIME) {
            long elapsed = System.currentTimeMillis() - now;
            Log.d(TAG, "Drawing took " + elapsed + " ms");
        }
    }

    private void drawReflection(Canvas canvas) {
        Log.i(TAG, "drawReflection");
        View child = getChildAt(0);
        child.setDrawingCacheEnabled(true);

        child.buildDrawingCache();
        int childw = child.getWidth();
        int childh = child.getHeight();
        int selfh = getHeight();
        int poolh = selfh - childh;
        /*
         * Save a layer so that we can render off screen initially in order to
         * achieve the DST_OUT xfer mode. This allows us to have a non-solid
         * background.
         */
        canvas.saveLayer(child.getLeft(), child.getBottom(), child.getRight(), child.getBottom() + getBottom(), null, Canvas.ALL_SAVE_FLAG);
        // Draw the flipped child.
        canvas.save();
        canvas.scale(1, -1);
        canvas.translate(0, -(childh * 2));
        child.draw(canvas);
        canvas.restore();
//        /* Carve out the reflection area's alpha channel. */
        mMatrix.setScale(1, poolh);
        mMatrix.postTranslate(0, childh);
        mShader.setLocalMatrix(mMatrix);
        canvas.drawRect(0, childh, childw, selfh, mReflectionPaint);
        //Apply the canvas layer.
        canvas.restore();
    }

    public void updateRefect(){
        Log.i(TAG, "updateRefect ");
        postInvalidate();
    }

}
