package com.example.mylayout;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button mBtnLinearLayout;
    private Button mBtnRelativeLayout;
    private Button mBtnFrameLayout;
    private Button mBtnTableLayout;
    private Button mBtnGridLayout;
    private Button mBtnConstraintLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mBtnLinearLayout = findViewById(R.id.linear_layout);
        mBtnRelativeLayout = findViewById(R.id.relative_layout);
        mBtnFrameLayout = findViewById(R.id.frame_layout);
        mBtnTableLayout = findViewById(R.id.table_layout);
        mBtnGridLayout = findViewById(R.id.grid_layout);
        mBtnConstraintLayout = findViewById(R.id.constraint_layout);

        setOnClickListener();
    }

    private void setOnClickListener() {
        OnClick clickListener = new OnClick();
        mBtnLinearLayout.setOnClickListener(clickListener);
        mBtnRelativeLayout.setOnClickListener(clickListener);
        mBtnFrameLayout.setOnClickListener(clickListener);
        mBtnTableLayout.setOnClickListener(clickListener);
        mBtnGridLayout.setOnClickListener(clickListener);
        mBtnConstraintLayout.setOnClickListener(clickListener);
    }

    class OnClick implements View.OnClickListener {

        @Override
        public void onClick(View view) {
            Intent intent = null;

            switch (view.getId()) {
                case R.id.linear_layout:
                    intent = new Intent(MainActivity.this, LinearLayoutActivity.class);
                    break;
                case R.id.relative_layout:
//                    intent = new Intent(MainActivity.this, RelativeLayoutActivity.class);
                    break;
                case R.id.frame_layout:
//                    intent = new Intent(MainActivity.this, FrameLayoutActivity.class);
                    break;
                case R.id.table_layout:
//                    intent = new Intent(MainActivity.this, TableLayoutActivity.class);
                    break;
                case R.id.grid_layout:
//                    intent = new Intent(MainActivity.this, GridLayoutActivity.class);
                    break;
                case R.id.constraint_layout:
                    intent = new Intent(MainActivity.this, ConstraintLayoutActivity.class);
                    break;
                default:
                    return;
            }

            startActivity(intent);
        }
    }
}